-module(dropboxtest).
-export([start/0, client/1]).

start() ->
     dropbox:start(),
     mutex:start(),
	register(tester_process, self()),
	loop("file1", "file2", 10),
	unregister(tester_process),
	mutex:stop(),
	dropbox:stop().

loop(_, _, 0) ->
     true;

loop(FirstString, SecondString, N) ->
     dropbox:write(""),
	spawn(dropboxtest, client, [FirstString]),
	spawn(dropboxtest, client, [SecondString]),
     receive
	done -> true
     end,
     receive
	done -> true
     end,
	
	io:format("Expected string = ~ts, actual string = ~ts~n~n",
       [(FirstString ++ SecondString), dropbox:read()]),
	loop(FirstString, SecondString, N-1).

client(Str) ->
     dropbox:upload(Str),
	tester_process ! done.
	
